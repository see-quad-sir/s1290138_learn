class frequenciesOfItems:
    def __init__(self, db, sep='\t'):
        self.db = db
        self.sep = sep