class heatMapItemsFrequencies:
    def __init__(self, dic):
        self.dic = dic